package org.javaro.lecture;

public class Book {
    private String isbn, title, author;
    private Student student;

    public Book(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public String toString() {
        String available;
        if (getStudent() == null) {
            available = "대출가능";
        } else {
            available = "대출자 = " + getStudent().getName();
        }
        return "ISBN=" + getIsbn() + ",제목=" + getTitle() + ",저자=" + getAuthor() + "," + available;
    }
}