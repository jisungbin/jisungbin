package org.javaro.lecture;

import java.util.ArrayList;

public class BookStore {
    private String storeName;
    private ArrayList<Book> books = new ArrayList<>();
    private ArrayList<Student> students = new ArrayList<>();

    public BookStore(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public ArrayList<Book> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<Book> books) {
        this.books = books;
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        this.students = students;
    }

    public void addBook(Book book) {
        this.books.add(book);
    }

    public void removedBook(Book book) {
        this.books.remove(book);
    }

    public void addStudent(Student student) {
        this.students.add(student);
    }

    public void removeStudent(Student student) {
        this.students.remove(student);
    }

    public Boolean checkOut(Book book, Student student) {
        if (book.getStudent() == null) {
            book.setStudent(student);
            return true;
        } else {
            return false;
        }
    }

    public Boolean checkIn(Book book) {
        if (book.getStudent() != null) {
            book.setStudent(null);
            return true;
        } else {
            return false;
        }
    }

    public ArrayList<Book> getBooksForStudents(Student student) {
        ArrayList<Book> result = new ArrayList<>();
        for (Book aBook : this.getBooks()) {
            if (aBook.getStudent() == null) {
                result.add(aBook);
            }
        }
        return result;
    }

    public ArrayList<Book> getAvailableBooks() {
        ArrayList<Book> result = new ArrayList<>();
        for (Book aBook : this.getBooks()) {
            if (aBook.getStudent() == null) {
                result.add(aBook);
            }
        }
        return result;
    }

    public ArrayList<Book> getUnavailableBooks() {
        ArrayList<Book> result = new ArrayList<>();
        for (Book aBook : this.getBooks()) {
            if (aBook.getStudent() != null) {
                result.add(aBook);
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return this.getStoreName() + "의 보유책=" + getBooks().size() + "권, 회원수=" + getStudents().size() + "명";
    }

    public void printStatus() {
        System.out.println("--- 도서관 현황 ---\n" + toString());
        for (Book aBook : this.getBooks()) {
            System.out.println(aBook);
        }
        for (Student student : this.getStudents()) {
            int count = getBooksForStudents(student).size();
            System.out.println(student.getName() + "은/는 " + count + "권 대출중");
        }
        System.out.println("현재 대출 가능 책: " + getAvailableBooks().size());
        System.out.println("--- 리포트 종료 ---");
    }
}
