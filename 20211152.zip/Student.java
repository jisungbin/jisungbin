package org.javaro.lecture;

public class Student {
    private String name, studNumber;

    public Student(String studNumber) {
        this.studNumber = studNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudNumber() {
        return studNumber;
    }

    public void setStudNumber(String studNumber) {
        this.studNumber = studNumber;
    }
}