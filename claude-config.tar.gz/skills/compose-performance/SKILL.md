---
name: compose-performance
description: Compose 컴파일러 동작 원리 기반의 성능 최적화 가이드. 코드 리뷰, 컴포저블 작성, 성능 개선 시 참고.
triggers:
  - "컴포즈 성능"
  - "컴포즈"
  - "compose 성능"
  - "compose"
  - "리컴포지션"
  - "recomposition"
  - "stability"
  - "안정성"
  - "skippable"
  - "restartable"
---

# Compose Performance Skill

> Compose 컴파일러의 실제 동작 원리에 기반한 성능 최적화 가이드.
> 근거: Kotlin 2.1.20 Compose 컴파일러 소스 및 동작 분석 문서.

---

## 1. 핵심 원리

Compose 컴파일러는 모든 `@Composable` 함수를 변환한다. 성능은 이 변환 결과가 얼마나 많은 코드를 스킵할 수 있느냐에 달렸다.

```
소스 코드 -> [안정성 추론] -> [그룹 결정] -> [$changed 구성] -> [스킵 판정] -> 런타임 실행
```

개발자가 개입할 수 있는 지점은 **안정성 추론**과 **그룹 결정**에 영향을 주는 코드 작성 패턴이다.

### 1.1 리컴포지션 스킵의 전제 조건

스킵이 발생하려면 **세 가지 조건이 모두** 충족되어야 한다:

1. 함수가 **Restart Group**을 가짐 (restartable)
2. 함수가 **Skippable** (모든 매개변수가 stable이거나 Strong Skipping 활성)
3. 모든 tracked parameter가 **Same** 상태이고, `$changed`의 LSB가 0

### 1.2 매개변수 상태 비트

컴파일러는 각 매개변수를 3비트 슬롯으로 추적한다:

| ParamState | 비트 | 의미 | 스킵 |
|---|---|---|---|
| `Static` | `0b011` | 절대 변하지 않음 | O (비교 생략) |
| `Same` | `0b001` | 이전과 동일 | O |
| `Different` | `0b010` | 변경됨 | X |
| `Uncertain` | `0b000` | `equals()` 호출 필요 | 결과에 따름 |
| `Unknown` | `0b100` | 불안정 타입 | Strong Skipping 필요 |

---

## 2. Stable 타입 지향

### 2.1 즉시 Stable인 타입 (추론 비용 0)

```kotlin
// 원시타입
Int, Long, Float, Double, Boolean, Char, Byte, Short

// 특수 타입
String, Unit

// 함수 타입
() -> Unit, (Int) -> String, @Composable () -> Unit
```

컴포저블 매개변수를 이 타입들로 분해하면 추론 비용 없이 Stable을 확보한다.

```kotlin
// BAD - User 클래스의 안정성 추론 필요
@Composable fun Profile(user: User) { ... }

// GOOD - 원시타입으로 분해, 즉시 Stable
@Composable fun Profile(name: String, age: Int, avatarUrl: String) { ... }
```

### 2.2 클래스를 Stable로 만드는 규칙

```
1. delegated가 아닌 var가 하나라도 있으면 -> 즉시 Unstable (다른 필드 무시)
2. 모든 val 프로퍼티의 타입이 stable이면 -> Stable
3. superClass가 unstable이면 -> 하위 클래스도 Unstable
```

```kotlin
// Unstable - var 존재
data class UserState(var loading: Boolean, val name: String)

// Stable - 모든 val이 stable 타입
data class UserState(val loading: Boolean, val name: String)

// Unstable - List는 interface -> Unknown
data class UserState(val items: List<String>)

// Stable - ImmutableList는 KnownStableConstructs에 등록됨
data class UserState(val items: ImmutableList<String>)
```

### 2.3 delegated var은 예외

컴파일러는 delegated property가 아닌 var만 즉시 unstable로 판정한다.

```kotlin
class MyState {
    var count: Int by mutableStateOf(0)  // delegated var -> unstable이 아님
    // delegate 타입(MutableState)의 안정성으로 추론
    // MutableState는 @Stable -> 전체 클래스도 Stable 가능
}
```

### 2.4 interface는 항상 Unknown

```kotlin
interface Repository { fun getData(): String }

@Composable fun Screen(repo: Repository) { ... }
// repo: Unknown -> Strong Skipping 없으면 절대 스킵 불가
```

해결 방법 (우선순위 순):

1. `@Stable` 어노테이션 추가
2. 구체 클래스 사용
3. stability configuration 파일에 등록

### 2.5 외부 모듈 타입

```
외부 Kotlin 모듈 + @StabilityInferred 있음 -> Runtime (MSB로 판단)
외부 Kotlin 모듈 + @StabilityInferred 없음 -> Unstable
외부 Java 모듈                              -> 항상 Unstable
```

해결: `stability_config.conf` 파일 활용

```
// stability_config.conf
java.time.LocalDate
java.time.LocalDateTime
com.example.thirdparty.models.**
```

### 2.6 제네릭 타입

제네릭 클래스는 비트마스크로 type parameter의 안정성 영향을 인코딩한다.

```kotlin
class Box<T>(val value: T)
// @StabilityInferred(parameters = 0b1) -> T가 안정성에 영향

Box<Int>      // T=Int(Stable) -> Stable
Box<Counter>  // T=Counter(Unstable) -> Unstable
```

제네릭 컨테이너를 매개변수로 받을 때, **type argument까지 stable**이어야 한다.

### 2.7 unstable 상위 클래스 해결

상속 구조 재설계만이 답이 아니다. 상위 클래스 자체를 stable로 만들 수 있다:

```kotlin
// 방법 1: @Stable 마킹 (계약 준수 가능할 때)
@Stable
open class Base(var state: Int)

// 방법 2: var를 val로 변경
open class Base(val state: Int)

// 방법 3: delegated property로 변환
open class Base {
    var state: Int by mutableStateOf(0)
}

// 방법 4: 외부 모듈이면 stability config 등록
// stability_config.conf:
// com.thirdparty.BaseClass
```

### 2.8 순환 참조 타입

```kotlin
class Node(val value: Int, val next: Node?)
// 순환 감지 -> Unstable (보수적 판정)
```

실제로는 immutable 구조일 수 있으나 컴파일러는 unstable로 판정한다.
해결: `@Stable` 또는 `@Immutable` 어노테이션.

---

## 3. RestartGroup 지향

### 3.1 그룹 유형과 성능 영향

| 그룹 | 생성 조건 | 스킵 가능 | 리컴포지션 범위 |
|---|---|---|---|
| **Restart Group** | restartable + Unit 반환 | O (조건 충족 시) | 자기 자신만 |
| **Replace Group** | non-restartable 또는 Unit 외 반환 | X | 부모가 리컴포지션 |
| **없음** | `@ReadOnlyComposable` 등 | X | 부모가 리컴포지션 |

Restart Group이 있어야 해당 함수만 독립적으로 리컴포지션할 수 있다.

### 3.2 Restartable이 되지 않는 조건들

```
- inline 함수
- 반환 타입이 Unit이 아닌 경우
- 람다 (ComposableLambda 클래스를 대신 사용)
- @Composable fun interface 구현체가 아닌 로컬 함수
- @NonRestartableComposable
- @ExplicitGroupsComposable
- val a by remember { mutableStateOf(..) } 같은 델리게이트
- $composer 매개변수가 없는 경우
- 기본 인자가 있는 컴포저블의 원본 함수 (스텁만 restartable)
- open 함수
```

```kotlin
// BAD - open이므로 restartable 불가
open class BaseScreen {
    @Composable open fun Content() { ... }
}

// GOOD - final이므로 restartable
@Composable fun Content() { ... }
```

```kotlin
// BAD - Unit 외 반환이므로 restartable 불가
@Composable fun calculateValue(): Int { ... }

// GOOD - Unit 반환
@Composable fun DisplayValue() { Text(calculateValue().toString()) }
```

### 3.3 리컴포지션 범위 최소화 전략

```kotlin
// BAD - Screen 전체가 하나의 restart group
@Composable fun Screen(viewModel: ViewModel) {
    val count by viewModel.count.collectAsState()
    val name by viewModel.name.collectAsState()

    Text("$name: $count")  // count 변경 시 Screen 전체 재실행
    ExpensiveList(...)      // 불필요하게 재실행
}

// GOOD - 변경 가능한 부분을 별도 restart group으로 분리
@Composable fun Screen(viewModel: ViewModel) {
    CounterSection(viewModel)  // count 변경 시 여기만 재실행
    ExpensiveList(...)         // 영향 없음
}

@Composable fun CounterSection(viewModel: ViewModel) {
    val count by viewModel.count.collectAsState()
    val name by viewModel.name.collectAsState()
    Text("$name: $count")
}
```

### 3.4 @NonRestartableComposable 활용

리컴포지션 스킵이 의미 없는 단순 위임 함수에 사용한다:

```kotlin
@NonRestartableComposable
@Composable fun MyButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick) { Text(text) }
}
// -> restart group 대신 replace group (또는 그룹 없음)으로 오버헤드 감소
// 주의: 이 함수 자체는 스킵 불가, 부모가 리컴포지션해야 함
```

---

## 4. Static Expression 최적화

### 4.1 Static이 주는 이점

Static 표현식은 `$changed` 슬롯에 `Static(0b011)` 상태가 들어가며, `changed()` 호출 자체를 건너뛴다. 가장 좋은 최적화 상태다.

### 4.2 Static으로 인정되는 조건

```
- 상수 리터럴 (42, "hello", true)
- enum entry 참조
- companion object 참조
- stable 타입의 object 참조
- @Immutable 클래스의 생성자 호출 (모든 인자가 static일 때)
- val 변수 참조 (initializer가 static일 때)
- stable 반환 + @Stable 함수 호출 (모든 인자가 static일 때)
- top-level const 프로퍼티 GET
- remember {} (key 없고 반환 타입이 stable일 때)
- composableLambda / rememberComposableLambda 호출
```

### 4.3 @Immutable vs @Stable 차이

안정성 추론에서는 동일하지만, Static 판별에서 차이가 있다:

```kotlin
@Immutable data class ImmutablePoint(val x: Int, val y: Int)
@Stable data class StablePoint(val x: Int, val y: Int)

@Composable fun Example() {
    // Static expression - @Immutable + 모든 인자 static
    val p1 = ImmutablePoint(10, 20)

    // NOT static - @Stable은 static constructor로 인정되지 않음
    val p2 = StablePoint(10, 20)
}
```

진정으로 불변인 데이터 클래스에는 `@Stable`이 아닌 `@Immutable`을 쓰면 추가 최적화를 얻는다.

### 4.4 기본 매개변수와 Static

기본 매개변수가 `@Immutable` 타입이고, 인자가 명시되지 않았다면 항상 인자값을 static으로 다룬다.

```kotlin
@Immutable data class Config(val theme: String = "light")

@Composable fun App(config: Config = Config()) {
    // config 인자가 제공되지 않으면 -> Static으로 처리
    // $dirty 슬롯에 Static(0b011) 삽입 -> changed() 호출 생략
}
```

---

## 5. $changed 비교 전파 최적화

### 5.1 전파 메커니즘

상위 함수의 `$dirty` 정보가 하위 호출의 `$changed`로 전파된다. 컴파일러 분기 우선순위:

```
1. 인자 표현식이 Static        -> $changed에 Static 삽입 (최상: 비교 완전 생략)
2. 상위 매개변수를 직접 레퍼런스 -> $dirty 비트 그대로 복사 (최상: 비교 완전 생략)
3. Stable + $dirty 사용 가능   -> $dirty 기반 조건부 비교 (양호)
4. Unstable이 아님 + $dirty    -> 조건부 changed() 호출 (보통)
5. 그 외                      -> changed(inferredStable=false) (나쁨)
```

### 5.2 매개변수 가공과 전파

매개변수를 가공해도 **결과가 Stable 타입이면 스킵은 정상 동작**한다.
단, 직접 전달 대비 `equals()` 호출 비용이 추가된다.

```kotlin
@Composable fun Parent(name: String) {
    // 분기 2: $dirty 비트 복사 - equals() 호출 없음
    Child(name = name)

    // 분기 3~4: Stable 가공 - equals() 호출 발생, 스킵은 가능
    Child(displayName = "Hello, $name")
}
```

| 전달 방식 | 분기 | `changed()` 호출 | 스킵 가능 |
|---|---|---|---|
| 직접 전달 | 2 ($dirty 복사) | 없음 | O |
| Stable 가공 | 3~4 | 매 리컴포지션마다 | O |
| Unstable 가공 | 5 | 매번 + inferredStable=false | Strong Skipping 필요 |

대부분의 경우 `equals()` 비용은 무시할 수 있으므로 Stable 가공은 충분히 괜찮다.
hot path에서 `equals()` 비용이 큰 타입(대규모 컬렉션 등)만 직접 전달을 고려한다.

---

## 6. 람다 메모이제이션 최적화

### 6.1 메모이제이션 레벨

| 레벨 | 조건 | 결과 | 비용 |
|---|---|---|---|
| **Singleton** | 캡처 없음 + private 부모 | `ComposableSingletons` 객체에 저장 | 거의 0 |
| **Static** | 캡처 없음 + public 부모 | `composableLambda(useRememberingFactory)` | 낮음 |
| **remember 래핑** | stable 캡처 있음 | `remember(keys) { lambda }` | 중간 |
| **메모이제이션 없음** | 아래 조건 해당 | 매번 새 인스턴스 | 높음 |

### 6.2 메모이제이션이 불가능한 경우

```kotlin
// 1. var 변수 캡처
var count = 0
val lambda = { count++ }

// 2. @DontMemoize 람다
@DontMemoize val lambda = @Composable { ... }

// 3. inline 함수의 noinline이 아닌 람다를 캡처
inline fun doSomething(block: () -> Unit) { ... }
val captured = { doSomething { } }

// 4. 프로퍼티 레퍼런스 델리게이션 캡처
val prop by someDelegate
val lambda = { prop }

// 5. Unit 외 반환 (컴포저블 람다)
val lambda: @Composable () -> Int = { 42 }
```

### 6.3 실전 람다 최적화

```kotlin
// BAD - unstable 캡처 (Strong Skipping 없으면 메모이제이션 불가)
@Composable fun Parent(viewModel: ViewModel) {
    Child(onClick = { viewModel.doSomething() })
}

// GOOD - 캡처 없는 람다 (Singleton으로 최적화)
@Composable fun Parent() {
    Child(onClick = { /* 캡처 없음 */ })
}
```

### 6.4 비컴포저블 람다도 메모이제이션된다

```kotlin
@Composable fun Example() {
    // 컴포저블 스코프 안의 일반 람다도 remember로 래핑됨
    val callback: () -> Unit = { println("hello") }
    // -> remember { { println("hello") } }

    // SAM 변환도 메모이제이션됨
    val closeable = Closeable { }
    // -> remember { Closeable { } }
}
```

---

## 7. 체크리스트

### Tier 1: 반드시 적용

| # | 항목 | 근거 |
|---|---|---|
| 1 | 모든 데이터 클래스의 프로퍼티를 `val`로 | delegated 아닌 var -> 즉시 Unstable |
| 2 | `List`/`Set`/`Map` 대신 `ImmutableList`/`ImmutableSet`/`ImmutableMap` 사용 | interface -> Unknown |
| 3 | 변경이 빈번한 state를 읽는 부분을 별도 컴포저블로 분리 | restart group 범위 최소화 |
| 4 | 외부 라이브러리 타입은 stability config에 등록 | @StabilityInferred 없는 외부 타입 -> Unstable |
| 5 | 컴포저블 반환 타입을 `Unit`으로 유지 | Unit 외 -> restartable 불가 |

### Tier 2: 적극 권장

| # | 항목 | 근거 |
|---|---|---|
| 6 | 진정한 불변 클래스에는 `@Immutable` 사용 (`@Stable` 대신) | static constructor 인정 -> 추가 최적화 |
| 7 | 캡처 없는 람다를 선호 | ComposableSingleton으로 최적화 (비용 0) |
| 8 | interface 매개변수에 `@Stable` 마커 추가 | Unknown -> Stable |
| 9 | open/abstract 컴포저블 피하기 | open -> restartable 불가 |
| 10 | unstable 상위 클래스는 `@Stable` 마킹 / var를 val이나 delegated로 변환 | superClass unstable -> 하위도 Unstable |

### Tier 3: 세밀한 튜닝

| # | 항목 | 근거 |
|---|---|---|
| 11 | 상수를 `const val` 또는 리터럴로 | Static expression -> 비교 완전 생략 |
| 12 | 단순 래퍼 컴포저블에 `@NonRestartableComposable` | 불필요한 restart group 제거 |
| 13 | `@ReadOnlyComposable`로 state 읽기 전용 함수 표시 | 그룹 생성 자체를 생략 |
| 14 | value class 활용 (감싸는 타입이 stable할 때) | value class -> 내부 타입 기준 추론 |
| 15 | `remember` key에 stable 값만 사용 | key가 모두 static이면 remember 자체가 static |
| 16 | hot path에서 대규모 컬렉션은 가공 없이 직접 전달 | $dirty 비트 복사 -> equals() 호출 생략 |

### Anti-patterns

| 패턴 | 문제 | 대안 |
|---|---|---|
| `data class X(var ...)` | 즉시 Unstable | `val`로 변경 |
| `@Composable fun x(): Int` | restartable 불가 | Unit 반환 분리 |
| 람다 안에서 `var` 캡처 | 메모이제이션 불가 | state hoisting |
| unstable 상위 클래스 상속 | 하위도 Unstable | superClass를 `@Stable`로 / var를 val이나 delegated로 / stability config 등록 |
| 자기 참조 `class A(val a: A)` | 순환 감지 -> Unstable | `@Stable` 또는 `@Immutable` |

---

## 8. 진단 도구

### 컴파일러 리포트 활성화

```kotlin
// build.gradle.kts
composeCompiler {
    reportsDestination = layout.buildDirectory.dir("compose_reports")
    metricsDestination = layout.buildDirectory.dir("compose_metrics")
    stabilityConfigurationFile = rootProject.layout.projectDirectory.file("stability_config.conf")
}
```

### 확인 포인트

- `*-classes.txt`에서 `unstable` 클래스 찾기
- `*-composables.txt`에서 `restartable`이지만 `skippable`이 아닌 함수 찾기
- 해당 함수의 unstable 매개변수를 식별하고 체크리스트 적용

```
// 이상적인 출력
restartable skippable fun UserProfile(stable user: User)

// 문제 있는 출력 - skippable 누락
restartable fun UserProfile(unstable user: User)
```
