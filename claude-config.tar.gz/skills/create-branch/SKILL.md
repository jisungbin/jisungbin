---
name: create-branch
description: Use when the user asks to create a git branch, make a branch, or says "브랜치 만들고", "브랜치 생성". Prefixes all branch names with the user's username "f/".
triggers:
  - "브랜치 만들고"
  - "브랜치 생성"
  - "브랜치 만들어"
  - "create branch"
  - "make branch"
  - "new branch"
---

# Create Branch

사용자의 유저네임 `f`를 prefix로 하여 git 브랜치를 생성한다.

## 규칙

- 브랜치 이름은 반드시 `f/` 접두사로 시작해야 한다.
- 사용자가 브랜치 이름을 제공하면 `f/{브랜치이름}` 형식으로 생성한다.
- 사용자가 브랜치 이름을 제공하지 않으면 브랜치 이름을 물어본다.
- 브랜치 이름에 공백이 있으면 `-`로 대체한다.

## 예시

| 사용자 입력 | 생성되는 브랜치 |
|---|---|
| "브랜치 만들고 fix-login" | `f/fix-login` |
| "add-feature 브랜치 만들어줘" | `f/add-feature` |
| "브랜치 만들고" (이름 미제공) | 이름을 물어본 후 `f/{이름}` 생성 |

## 실행

```bash
git checkout -b f/<branch-name>
```
