---
name: prd
description: Comprehensive PRD (Product Requirements Document) writer that transforms ambiguous ideas into concrete specifications through Socratic dialogue, multi-persona analysis, and systematic requirements discovery. Creates structured PRDs under docs/proposals following template structure with cross-session persistence.
triggers:
  - "PRD"
  - "prd"
  - "create a PRD"
  - "write a PRD"
  - "document requirements"
  - "I want to build"
  - "I have an idea"
  - "explore requirements"
  - "break down the requirements"
  - "create proposal"
  - "document feature"
  - "write up the requirements"
  - "PRD 작성"
  - "PRD 만들어"
  - "요구사항 정리"
  - "요구사항 문서"
  - "제안서 작성"
  - "기획서 작성"
  - "기능 문서화"
  - "아이디어 정리"
  - "만들고 싶은 게 있어"
  - "기능 기획"
  - "요구사항 분석"
  - "제안서 만들어"
---

# PRD - Proposal Product Requirements Document Discovery and Writer

A systematic approach to transforming vague ideas into comprehensive, actionable Product Requirements Documents through interactive exploration, multi-domain analysis, and structured documentation.

## Activation Triggers

This skill activates when the user requests:
- **PRD Creation**: "create a PRD for...", "write a PRD about...", "document requirements for...", "PRD 작성해줘", "PRD 만들어줘"
- **Requirements Discovery**: "I want to build...", "I have an idea for...", "explore requirements for...", "만들고 싶은 게 있어", "아이디어가 있는데"
- **Feature Exploration**: "help me understand what we need for...", "break down the requirements for...", "요구사항 분석해줘", "기능 기획해줘"
- **Proposal Documentation**: "create proposal X", "document feature Y", "write up the requirements", "제안서 작성해줘", "기획서 만들어줘"
- **Vague Ideas**: Any ambiguous or high-level feature request needing systematic exploration
- **Depth Flags**: Requests with `--depth shallow`, `--depth normal`, or `--depth deep`, deep is default

## Core Capabilities

**Requirements Discovery**: Transform ambiguous concepts through Socratic dialogue and systematic questioning to uncover hidden requirements and clarify user intentions.

**Multi-Persona Orchestration**: Coordinate analysis across architecture, frontend, backend, security, analysis, and project management domains for comprehensive feasibility assessment.

**Structured Documentation**: Generate PRDs following standardized templates with sequence diagrams, API specifications, database schemas, and implementation guidance.

**Cross-Session Persistence**: Maintain discovery context and project knowledge across sessions using memory management for iterative refinement.

## Behavioral Flow

### 1. Verify Template

**Action**: Use the template file at `./template/PRD.md` as the structural reference for creating new PRDs.

**Template Usage**:
- Always read `./template/PRD.md` before generating a PRD to understand current structure
- Template structure is the single source of truth for PRD format

### 2. Explore

**Interactive Socratic Dialogue**: Use step-by-step questioning with numbered options for ease of selection.

**Exploration Process**:
1. **Present one focused question at a time** to avoid overwhelming the user
2. **Provide numbered options** for well-known solutions and patterns
3. **Allow custom responses** by letting users type details if none of the numbered options fit
4. **Build progressively** on each answer to uncover deeper requirements

**Question Categories & Format**:

**Problem & User Context**:
- "What problem does this solve for users?"
  - Present 3-5 common problem categories with numbers
  - Option to describe custom problem

**Target Users & Workflows**:
- "Who are the primary users?"
  1. Internal team members
  2. External customers/clients
  3. API consumers/developers
  4. System administrators
  5. Other (please specify)

**Success Criteria**:
- "What defines success for this feature?"
  1. Performance improvement (specify metrics)
  2. User experience enhancement
  3. Cost reduction
  4. Scalability improvement
  5. Security enhancement
  6. Other (please specify)

**Technical Approach**:
- Present domain-specific numbered options based on the feature type
- Example for async processing:
  1. Message queue (Redis, RabbitMQ, SQS)
  2. Background job system (Celery, Bull, Sidekiq)
  3. Event-driven architecture
  4. Async/await patterns only
  5. Other (please specify)

**Integration & Dependencies**:
- "How should this integrate with existing systems?"
  1. REST API integration
  2. Event-based integration
  3. Direct database access
  4. Shared library/module
  5. Other (please specify)

**Performance & Scale**:
- "What are the expected performance requirements?"
  1. Low latency (<100ms)
  2. High throughput (>1000 req/s)
  3. Large data volumes (>1TB)
  4. Real-time processing
  5. Batch processing acceptable
  6. Other (please specify)

**Response Format Instructions**:
- **Single number**: Quick selection (e.g., "2" or "1,3")
- **Number + details**: Selection with additional context (e.g., "1 - using Redis for job queue")
- **Custom text**: Full description when none of the options fit

**Progressive Questioning Strategy**:
- Start with high-level questions (problem, users, goals)
- Progress to technical details (approach, integration, performance)
- Adapt follow-up questions based on previous answers
- Ask clarifying questions only when responses are ambiguous
- Build on responses to uncover edge cases and constraints

**Depth-Based Question Count**:
- `--depth shallow`: 3-5 focused questions with numbered options
- `--depth normal`: 5-8 questions covering core aspects
- `--depth deep` (default): 10-15+ questions for comprehensive exploration

### 3. Analyse Idea and Existing Code

**Code Analysis**: Use Serena MCP to:
- Examine existing architecture and patterns
- Identify relevant components and integration points
- Understand current implementation patterns and conventions
- Assess technical feasibility and implementation approach

**Multi-Persona Coordination**: Activate relevant personas based on the scope:
- **Architect**: System design, architecture patterns, scalability
- **Analyser**: Feasibility assessment, risk analysis, trade-offs
- **Frontend**: UI/UX considerations, component design
- **Backend**: API design, database schema, business logic
- **Security**: Security requirements, access control, data protection
- **Project Manager**: Scope, timeline, resource requirements

### 4. Validate

**Feasibility Assessment**: Evaluate across domains:
- Technical feasibility and implementation complexity
- Resource requirements and timeline estimates
- Risk factors and mitigation strategies
- Integration challenges and dependencies
- Non-functional requirements (performance, security, scalability)

**Cross-Framework Validation**: Ensure requirements are:
- Complete: All aspects covered
- Consistent: No contradictions across domains
- Achievable: Realistic given constraints
- Testable: Clear success criteria defined

### 5. Iteration

**Refinement Loop**: Repeat steps 2-4 until:
- All functional requirements are clearly defined
- Non-functional requirements are specified
- Technical approach is validated
- Edge cases and error scenarios are covered
- Success criteria are measurable

**Convergence Indicators**:
- No new questions from personas
- User confirms understanding and completeness
- All requirements have concrete specifications

### 6. Specify

**Concrete Specifications**: Generate detailed requirements including:
- User stories with clear goals and rationale
- Sequence diagrams illustrating workflows (Mermaid syntax)
- API specifications with endpoints, request/response formats
- Event specifications for publishers and consumers
- Database schema definitions and changes
- Non-functional requirements with measurable criteria

**Implementation Briefs**: Provide actionable guidance for developers:
- Component breakdown and responsibilities
- Integration points and dependencies
- Testing strategy and validation approach
- Deployment considerations

### 7. Document

**PRD Creation**: Write the complete PRD following the template structure.

**Location Determination**:
- **Default**: `docs/proposals/{next_sequential_number}_{title_as_snake_case}/PRD.md`
- **Custom**: Check if user has specified a different proposals directory location
- **Discovery**: Search for existing proposal directories to infer the base location and naming patterns
- **Flexibility**: The proposal directory structure may vary by project; adapt accordingly

**Template Reference**: Follow the structure defined in `./template/PRD.md`

**Template Guidelines Filtering**: When generating PRD content from the template:
- Exclude all lines starting with `> ` (blockquote format) - these are template guidelines only
- These guideline lines serve as instructions for filling out sections but should NOT appear in the final PRD
- Replace guideline sections with actual content based on requirements discovery

**Naming Convention**: Each proposal directory follows the pattern:
- Format: `{sequential_number_4_digits}_{title_as_snake_case}/PRD.md`
- Example: `0001_async_operation/PRD.md`, `0042_job_based_translation/PRD.md`

**Quality Checks Before Writing**:
- Read the template file to ensure you understand the current structure
- All sections follow template structure exactly
- No template guideline lines (starting with `> `) appear in the final PRD
- Terminology aligns with `UBIQUITOUS_LANGUAGES.md` (if exists)
- Sequence diagrams use proper Mermaid syntax
- API specs include all required fields
- Database schemas are complete and normalized
- Template structure may have been customized; always verify current template before writing

## MCP Integration

**Sequential MCP**: Enable for complex multi-step reasoning:
- Structured exploration framework for systematic discovery
- Hypothesis testing and validation
- Multi-component analysis and synthesis
- Debate moderation for conflicting requirements

**Serena MCP**: Enable for project context and persistence:
- Cross-session memory management
- Codebase semantic understanding
- Symbol operations and navigation

## Key Patterns

**Socratic Dialogue**: Question-driven exploration leads to systematic requirements discovery through progressive questioning and iterative refinement.

**Multi-Domain Analysis**: Cross-functional expertise application provides comprehensive feasibility assessment and risk identification.

**Progressive Coordination**: Systematic exploration through multiple personas enables iterative refinement and validation.

**Specification Generation**: Transform abstract concepts into concrete, actionable implementation briefs with measurable success criteria.

## Guidelines

**Discovery First**: Never jump to implementation without thorough requirements exploration. Incomplete discovery leads to scope creep and rework.

**Depth Adaptation**: Adjust exploration depth based on complexity:
- `--depth shallow`: Quick validation for simple features (2-3 questions)
- `--depth normal`: Standard discovery for moderate complexity (5-7 questions, 3-4 personas)
- `--depth deep` (default): Comprehensive analysis for complex systems (10+ questions, all relevant personas)

**Persona Selection**: Activate personas based on domain relevance:
- Always include: Analyser (feasibility), Project Manager (scope)
- Add based on context: Architect (system design), Backend (APIs), Frontend (UI), Security (sensitive data)

**Non-Prescriptive**: Guide discovery without imposing solutions. Let user vision drive direction while surfacing considerations and trade-offs.

**Template Compliance**: Always read `./template/PRD.md` and verify PRD structure matches template before writing. Check for:
- All required sections present (template may be customized)
- Proper heading hierarchy
- No template guideline lines (starting with `> `) in the generated PRD
- Mermaid syntax validity for diagrams
- Standardized terminology (check UBIQUITOUS_LANGUAGES.md if exists)
- No markdown formatting violations per template rules
- Template structure is the single source of truth; do not assume default structure

**Iterative Refinement**: Don't rush to documentation. Continue exploration until:
- All functional requirements have concrete acceptance criteria
- Technical approach is validated by relevant personas
- Edge cases and error scenarios are identified
- User confirms completeness and understanding

**Session Management**: For complex discoveries:
- Checkpoint progress with Serena memory writes
- Enable resume of multi-session PRD development

**Quality Over Speed**: Prioritize comprehensive discovery over rapid documentation. A well-explored PRD prevents costly implementation rework. If possible, always use the best performing LLM models with reasoning.

## Boundaries

**Will:**
- Transform ambiguous ideas into concrete specifications through systematic exploration
- Coordinate multiple personas and MCP servers for comprehensive analysis
- Generate structured PRDs following template conventions
- Maintain cross-session context for iterative refinement
- Validate technical feasibility and identify risks
- Create actionable implementation guidance

**Will Not:**
- Make implementation decisions without proper requirements discovery
- Override user vision with prescriptive solutions during exploration phase
- Bypass systematic exploration for complex multi-domain projects
- Generate incomplete PRDs missing required template sections
- Proceed to documentation without user confirmation of completeness
- Implement the actual features (PRD creation only, not implementation)
