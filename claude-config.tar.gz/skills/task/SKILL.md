---
name: task
description: Manage proposal task lifecycle from PRD refinement to implementation completion. Converts PRDs into structured TASKS.md, implements specific tasks with full test coverage and quality validation, and tracks completion status.
triggers:
  - "generate tasks"
  - "create TASKS.md"
  - "break down proposal"
  - "implement task"
  - "work on task"
  - "start implementing"
  - "mark task as complete"
  - "task is done"
  - "complete task"
  - "태스크 생성"
  - "태스크 만들어"
  - "태스크 구현"
  - "태스크 완료"
  - "작업 분해"
  - "작업 구현"
  - "작업 완료"
  - "제안서 태스크"
  - "PRD에서 태스크"
  - "태스크 목록"
  - "작업 시작"
  - "구현 시작"
---

# Task - Proposal Task Refinement and Management

A systematic approach to converting Product Requirements Documents into actionable implementation tasks, executing them with quality assurance, and tracking completion status.

## Activation Triggers

This skill activates when the user requests:
- **Refinement**: "generate tasks from PRD", "create TASKS.md for proposal X", "break down proposal X into tasks", "태스크 생성해줘", "PRD에서 태스크 만들어줘", "제안서 X 작업 분해해줘"
- **Implementation**: "implement task X.X", "work on task X.X from proposal Y", "start implementing task X.X", "태스크 X.X 구현해줘", "작업 X.X 시작해줘"
- **Completion**: "mark task X.X as complete", "task X.X is done", "complete task X.X", "태스크 X.X 완료", "작업 X.X 끝났어"
- **General**: Any request involving proposal task management, TASKS.md generation, or task implementation

## Core Capabilities

**PRD Refinement**: Transform PRDs into structured TASKS.md with phases and implementation-ready tasks following template conventions.

**Task Implementation**: Execute specific tasks with full development lifecycle including planning, coding, testing, and validation.

**Completion Tracking**: Maintain accurate task status in TASKS.md to provide visibility into implementation progress.

**Quality Enforcement**: Ensure all implementations pass tests, linting, type checking, and project coding standards before completion.

## Prerequisites

This skill works with PRDs created by the PRD skill. Ensure a PRD exists before attempting to refine or implement tasks.

## Three-Action Workflow

### 1. Refine - Generate TASKS.md from PRD

**Purpose**: Convert a PRD into a structured TASKS.md with phases and implementation tasks.

**Activation**: User asks to create TASKS.md, generate tasks, or break down a proposal by number.

**Process**:

1. **Locate PRD**:
   - Locate the exactly same proposal directory of the related PRD
   - Default location: `docs/proposals/{number}_{name}/PRD.md`
   - Flexible: Search for existing proposals directory structure
   - Validate: Ensure PRD exists and is readable

2. **Analyze Requirements**:
   - Extract functional requirements from PRD
   - Identify user stories and technical specifications
   - Review API specifications, database schemas, and sequence diagrams
   - Understand non-functional requirements and constraints

3. **Break Down into Phases and Tasks**:
   - **Phase Level**: Story-level features representing significant milestones
   - **Task Level**: Implementation units representing 1 commit or a few commits at most
   - **Size Constraint**: Actual changed lines should be under 200 (excluding test code)
   - **Progressive Approach**: Start with skeleton, expand functionality iteratively

4. **Generate TASKS.md**:
   - Follow structure defined in `./template/TASKS.md`
   - Exclude all lines starting with `> ` (blockquote format) - these are template guidelines only
   - Include specific technical details from the PRD
   - Organize by logical phases with clear dependencies
   - Mention expected duration for each phase if possible

5. **Write to Proposal Directory**:
   - Location: Locate the exactly same proposal directory of the related PRD and create a file named `TASKS.md`
   - Validate template compliance before writing
   - Ensure all sections follow template structure
   - No template guideline lines (starting with `> `) should appear in the final TASKS.md

**Task Breakdown Principles**:
- **Small and Working**: Each task should produce working functionality
- **Self-Contained**: Minimize dependencies between tasks where possible
- **Testable**: Each task should have clear acceptance criteria
- **Incremental**: Build skeleton first, then expand with features
- **Realistic Scope**: Size tasks for single development sessions

### 2. Implement - Execute a Specific Task

**Purpose**: Implement a specific task from TASKS.md with full development lifecycle and quality assurance.

**Activation**: User asks to implement a specific task by ID (e.g., "implement task 1.1", "work on task 2.3").

**Process**:

1. **Load Context**:
   - Try default location: `docs/proposals/{number}_{name}/`
   - Read PRD.md from located proposal directory
   - Read TASKS.md from located proposal directory
   - Validate both files exist
   - Use Serena MCP for cross-session context if available

2. **Locate Task**:
   - Find task by ID (format: `1.1`, `2.3`, etc.)
   - Extract task description and implementation details
   - Identify related PRD sections and specifications
   - Understand dependencies on previous tasks

3. **Plan Implementation**:
   - Create TodoWrite breakdown with specific implementation steps
   - Plan test strategy (unit tests, integration tests, E2E tests)
   - Review project coding standards and patterns

4. **Execute Implementation**:
   - Implement core functionality first, then edge cases
   - Write comprehensive tests alongside implementation

5. **Quality Validation**:
   - Run project tests and quality checks if provided
   - Address any test failures or quality issues

6. **Verification Gate**:
   - All tests passing (unit, integration, E2E as applicable)
   - All quality checks passing (lint, format, type)
   - Code follows project conventions and patterns
   - Implementation matches task requirements from TASKS.md

**Implementation Pattern**:
```
Understand -> Plan (TodoWrite) -> Execute -> Test -> Validate -> Verify
```

**Quality Requirements**:
- **Tests**: Write tests before or alongside implementation (TDD/BDD encouraged)
- **Coverage**: Aim for high test coverage of new code
- **Standards**: Follow project coding style and conventions
- **Documentation**: Update inline comments and docstrings as needed
- **No Shortcuts**: Never skip tests or quality checks to complete faster

### 3. Complete - Mark Task as Completed

**Purpose**: Update TASKS.md to reflect task completion status for progress tracking.

**Activation**: User indicates a task is complete (e.g., "mark task 1.1 as complete", "task 2.3 is done").

**Process**:

1. **Load TASKS.md**:
   - Try default location: `docs/proposals/{number}_{name}/`
   - Read TASKS.md from located proposal directory
   - Validate file exists

2. **Locate Task**:
   - Find task by ID (e.g., `1.1`, `2.3`)
   - Verify task exists in TASKS.md

3. **Update Status**:
   - Append ` (Completed)` to the task title
   - Maintain all other formatting and structure

4. **Write Updated TASKS.md**:
   - Preserve all other content exactly
   - Maintain template structure and plain text format

**Status Format**:
```markdown
# Before
### Task 1.1: Implement async translation job foundation

# After
### Task 1.1: Implement async translation job foundation (Completed)
```

**Important**: Only mark tasks as complete AFTER successful implementation and validation.

## Directory Structure Flexibility

**Default Locations**:
- PRD: `docs/proposals/{number}_{name}/PRD.md`
- TASKS: `docs/proposals/{number}_{name}/TASKS.md`
- Template: `./template/TASKS.md` (relative to this skill)

**Discovery Strategy**:
- **Primary**: Try default location `docs/proposals/{number}_{name}/` first
- **Fallback**: If not found, search for proposal directory by number pattern (e.g., `0009_*`, `{number}_*`)
- **Flexible Adaptation**: Adapt to project-specific proposals directory structure
- **Validation**: Always validate file existence before operations

**Template Management**:
- Single source of truth: `./template/TASKS.md`
- Read template before generating TASKS.md
- Template may be customized per project
- Never hardcode template structure in implementation

## MCP Integration

**Serena MCP**: Primary tool for implementation tasks:
- Symbol operations: Navigate and modify code semantically
- Code navigation: Find references, definitions, and dependencies
- Cross-session persistence: Maintain context across sessions
- Project understanding: Analyze existing patterns and conventions
- Memory management: Store implementation progress and decisions

**Sequential MCP**: Enable for complex reasoning:
- Multi-step task analysis and breakdown
- Dependency analysis across tasks
- Risk assessment and mitigation planning
- Implementation strategy development

**Context7 MCP**: Use for framework-specific guidance:
- Framework patterns and best practices
- Library-specific implementation details
- Official documentation lookup

## Guidelines

**Task Refinement Best Practices**:
- **Read PRD Thoroughly**: Understand all requirements before breaking down
- **Logical Phases**: Group related tasks into coherent phases
- **Small Tasks**: Each task should be completable in a single session
- **Clear Descriptions**: Include specific technical details and acceptance criteria
- **Progressive Implementation**: Plan for skeleton -> working -> enhanced flow
- **Template Compliance**: Always read `./template/TASKS.md` before generating
- **Guideline Filtering**: Exclude all template guideline lines (starting with `> `) from the generated TASKS.md

**Implementation Best Practices**:
- **Context First**: Always read both PRD and TASKS.md before starting
- **Plan with TodoWrite**: Break down implementation into specific steps
- **Test-Driven**: Write tests alongside or before implementation
- **Quality Gates**: Never skip validation steps
- **Pattern Following**: Use Serena MCP to understand existing patterns
- **Incremental Commits**: Commit working functionality frequently

**Quality Standards**:
- **All Tests Pass**: No exceptions for quality gates
- **Code Standards**: Follow project conventions strictly
- **No Shortcuts**: Quality over speed always
- **Complete Implementation**: No TODOs or placeholders in production code
- **Regression Prevention**: Verify existing tests still pass

**Session Management**:
- Checkpoint progress with Serena memory writes
- Enable resumable multi-session implementations

**Task Size Calibration**:
- If task seems too large (>200 lines changed), break it down further
- If task seems too small (trivial change), consider combining with related tasks
- Aim for meaningful, self-contained units of work
- Adjust task granularity based on project complexity

## Integration with PRD Skill

**Natural Workflow**:
1. **Discovery**: Use PRD skill to explore requirements and create PRD
2. **Planning**: Use Task skill to refine PRD into TASKS.md
3. **Execution**: Use Task skill to implement each task systematically
4. **Validation**: Use Task skill completion tracking for progress visibility

**Shared Concepts**:
- Both use flexible directory structures
- Both reference template files for consistency
- Both emphasize quality over speed
- Both support cross-session persistence
- Both use Serena MCP for project understanding

**Terminology Alignment**:
- **Proposal**: The overall feature with PRD + TASKS.md
- **Phase**: Story-level milestone in TASKS.md
- **Task**: Implementation unit in TASKS.md (1 commit or few commits)
- **Todo**: Granular implementation step in TodoWrite

## Boundaries

**Will:**
- Generate structured TASKS.md from any PRD following template
- Implement tasks with full test coverage and quality validation
- Mark tasks as completed with accurate status tracking
- Enforce project coding standards and conventions
- Use Serena MCP for semantic code operations
- Validate all quality gates before completion
- Support cross-session implementation workflows

**Will Not:**
- Skip quality checks or tests to complete faster
- Implement tasks without understanding PRD context
- Mark tasks complete without proper validation
- Violate project guidelines or coding standards
- Create TODOs or placeholders in production code
- Proceed without proper test coverage
- Bypass any quality validation steps
