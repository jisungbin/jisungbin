#!/bin/bash

CACHE_FILE="/tmp/claude-usage-cache.json"
CACHE_TTL=60

fetch_usage() {
  local creds token data
  creds=$(security find-generic-password -s "Claude Code-credentials" -a "$(whoami)" -w 2>/dev/null)
  [[ -z "$creds" ]] && return 1
  token=$(echo "$creds" | jq -r '.claudeAiOauth.accessToken // .accessToken // empty')
  [[ -z "$token" ]] && return 1
  data=$(curl -s --max-time 5 \
    -H "Authorization: Bearer $token" \
    -H "Content-Type: application/json" \
    -H "anthropic-beta: oauth-2025-04-20" \
    "https://api.anthropic.com/api/oauth/usage" 2>/dev/null)
  if [[ -n "$data" ]] && echo "$data" | jq -e '.five_hour' >/dev/null 2>&1; then
    echo "$data" > "$CACHE_FILE"
  fi
}

# Read stdin (statusline JSON input)
input=$(cat)

# Get cached data or fetch
if [[ -f "$CACHE_FILE" ]]; then
  cache_age=$(( $(date +%s) - $(stat -f %m "$CACHE_FILE") ))
  if [[ $cache_age -ge $CACHE_TTL ]]; then
    fetch_usage &
  fi
  usage_data=$(cat "$CACHE_FILE")
else
  fetch_usage
  usage_data=$(cat "$CACHE_FILE" 2>/dev/null)
fi

# Build quota string
quota_str=""
if [[ -n "$usage_data" ]] && echo "$usage_data" | jq -e '.five_hour' >/dev/null 2>&1; then
  five_h_util=$(echo "$usage_data" | jq -r '.five_hour.utilization // 0' | cut -d. -f1)
  seven_d_util=$(echo "$usage_data" | jq -r '.seven_day.utilization // 0' | cut -d. -f1)

  quota_str="5h:${five_h_util}% wk:${seven_d_util}%"
fi

# Original statusline parts
cwd=$(echo "$input" | jq -r '.workspace.current_dir')
dir="${cwd/#$HOME/~}"
branch=$(cd "$cwd" 2>/dev/null && git rev-parse --abbrev-ref HEAD 2>/dev/null)
[[ -n "$branch" ]] && dir="$dir ($branch)"
in_tok=$(echo "$input" | jq -r '.context_window.total_input_tokens // 0')
out_tok=$(echo "$input" | jq -r '.context_window.total_output_tokens // 0')
total=$((in_tok + out_tok))
total_k=$(awk "BEGIN {printf \"%.1f\", $total/1000}")
pct=$(echo "$input" | jq -r '.context_window.used_percentage // 0' | cut -d. -f1)

# Animation frame counter
FRAME_FILE="/tmp/claude-animal-frame"
frame=$(cat "$FRAME_FILE" 2>/dev/null || echo 0)
frame=$(( (frame + 1) % 4 ))
echo $frame > "$FRAME_FILE"

# Context-responsive animal with animation
if [[ $pct -lt 30 ]]; then
  case $frame in
    0) animal="(˶ᵔ ᵕ ᵔ˶) ♪" ;;
    1) animal="(˶ᵔ ᵕ ᵔ˶)  ♪" ;;
    2) animal="(˶ᵔ ᵕ ᵔ˶) ♫" ;;
    3) animal="(˶ᵔ ᵕ ᵔ˶)  ♫" ;;
  esac
elif [[ $pct -lt 60 ]]; then
  case $frame in
    0) animal="(´｡• ᵕ •｡\`)    ~" ;;
    1) animal="(´｡• ᵕ •｡\`)   ~ " ;;
    2) animal="(´｡• ᵕ •｡\`)  ~  " ;;
    3) animal="(´｡• ᵕ •｡\`) ~   " ;;
  esac
elif [[ $pct -lt 85 ]]; then
  case $frame in
    0) animal="(´；ω；\`)  !" ;;
    1) animal="(´；ω；\`) !!" ;;
    2) animal="(´；ω；\`)  !" ;;
    3) animal="(´；ω；\`) . " ;;
  esac
else
  case $frame in
    0) animal="(╯°□°)╯    ︵ ┻━┻" ;;
    1) animal="(╯°□°)╯  ︵   ┻━┻" ;;
    2) animal="(╯°□°)╯︵     ┻━┻" ;;
    3) animal="(╯°□°)╯  ︵   ┻━┻" ;;
  esac
fi

if [[ -n "$quota_str" ]]; then
  echo "$dir | $quota_str | ${total_k}k tokens | ctx ${pct}% $animal"
else
  echo "$dir | ${total_k}k tokens | ctx ${pct}% $animal"
fi
